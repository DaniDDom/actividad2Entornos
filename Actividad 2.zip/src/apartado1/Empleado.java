package apartado1;

public class Empleado {
	private int codigo;
	private String DNI;
	private String nombre;
	private String direccion;
	private int NSS;
	private int telefono;

	public Empleado(int codigo, String dNI, String nombre, String direccion, int nSS, int telefono) {
		super();
		this.codigo = codigo;
		DNI = dNI;
		this.nombre = nombre;
		this.direccion = direccion;
		NSS = nSS;
		this.telefono = telefono;
	}

}
