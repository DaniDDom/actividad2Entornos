package apartado1;

public class departamento {
	private String nombre;
	private String localizacion;
	private int telefono;
	
	public departamento(String nombre, String localizacion, int telefono) {
		super();
		this.nombre = nombre;
		this.localizacion = localizacion;
		this.telefono = telefono;
	}
}
