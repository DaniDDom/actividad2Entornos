package apartado2;

public class habitacion {
	private int numHabitacion;
	private String nombre;
	private int wc;
	
	public habitacion(int numHabitacion, String nombre, int wc) {
		super();
		this.numHabitacion = numHabitacion;
		this.nombre = nombre;
		this.wc = wc;
	}
}
