package apartado2;

public class hotel {
	private String nombre;
	private String direccion;
	private int telefono;
	
	public hotel(String nombre, String direccion, int telefono) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		this.telefono = telefono;
	}
}
