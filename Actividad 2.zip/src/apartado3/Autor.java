package apartado3;

public class Autor {
	private String DNI;
	private String nombre;
	private String apellido1;
	private String apellido2;

	public Autor(String dNI, String nombre, String apellido1, String apellido2) {
		super();
		DNI = dNI;
		this.nombre = nombre;
		this.apellido1 = apellido1;
		this.apellido2 = apellido2;
	}
}
